# Smart-Server-Room
Upon graduation from Ege University, my friends and I built a project named Smart Server Room in 2016. 


The purpose of this project was to create a useful means of measuring live temperature, humidity and light of a server room, through the use of sensors that could be saved to an SD card and checked on a web interface. This project was created using Arduino Card and is to be used by those responsible for server room maintenance.
